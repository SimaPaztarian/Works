import { combineReducers } from 'redux'

import CounterReducer from '../containers/Counter/CounterReducer'

const reducers = combineReducers({
    CounterReducer
})

export default reducers
