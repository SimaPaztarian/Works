import React, { useState, useReducer } from 'react'

const initialState = {
    counter: 0
}

export const INCREMENT_COUNTER = 'INCREMENT_COUNTER'
export const incrementCounter = (step) => ({
    type: INCREMENT_COUNTER,
    step
})

export const DECREMENT_COUNTER = 'DECREMENT_COUNTER'
export const decrementCounter = (step) => ({
    type: DECREMENT_COUNTER,
    step
})

const CounterReducer = (state, action) => {
    const { type, step } = action

    switch (type) {
        case INCREMENT_COUNTER:
            return {
                ...state,
                counter: state.counter + step
            }
        case DECREMENT_COUNTER:
            return {
                ...state,
                counter: state.counter - step
            }
        default:
            return state

    }
}

function CounterWithHookReducer() {
    const [reducer, dispatch] = useReducer(CounterReducer, initialState)

    return (
        <>
            <h1>Counter with hook reducer</h1>

            <button onClick={() => dispatch(decrementCounter(1))}>
                <span>-1</span>
            </button>
            <span>{reducer.counter}</span>
            <button onClick={() => dispatch(incrementCounter(1))}>
                <span>+1</span>
            </button>
        </>
    )
}

export default CounterWithHookReducer
