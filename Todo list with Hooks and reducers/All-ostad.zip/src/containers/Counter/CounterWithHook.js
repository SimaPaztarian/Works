import React, { useState, useEffect } from 'react'

function CounterWithHook() {
    const [counter, setCounter] = useState(0)

    const increment = (step = 1) => {
        setCounter(counter => counter + step)
    }

    const decrement = (step = 1) => {
        setCounter(counter => counter - step)
    }

    return (
        <>
            <h1>Counter with hook</h1>

            <button onClick={() => {decrement(10)}}>
                <span>-10</span>
            </button>
            <button onClick={() => {decrement(5)}}>
                <span>-5</span>
            </button>
            <button onClick={() => {decrement()}}>
                <span>-1</span>
            </button>

            <input value={counter} onChange={(event) => {
                setCounter(parseInt(event.target.value))
            }}/>

            <button onClick={() => {increment()}}>
                <span>+1</span>
            </button>
            <button onClick={() => {increment(5)}}>
                <span>+5</span>
            </button>
            <button onClick={() => {increment(10)}}>
                <span>+10</span>
            </button>

        </>
    )
}

export default CounterWithHook
