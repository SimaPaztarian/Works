import { DECREMENT_COUNTER, INCREMENT_COUNTER, SET_COUNTER } from './CounterAction'

const initialState = {
    counter: 0
}

const CounterReducer = (state = initialState, action = {}) => {
    const { type, step, counter } = action

    switch (type) {
        case SET_COUNTER:
          return {
            ...state,
            counter: parseInt(counter)
          };
        case DECREMENT_COUNTER:
            return {
                ...state,
                counter: state.counter - step
            }
        case INCREMENT_COUNTER:
            return {
                ...state,
                counter: state.counter + step
            }
        default:
            return state
    }
}

export default CounterReducer
