export const SET_COUNTER = 'SET_COUNTER'
export const setCounter = (counter) => ({
    type: SET_COUNTER,
    counter
})

export const INCREMENT_COUNTER = 'INCREMENT_COUNTER'
export const incrementCounter = (step) => ({
    type: INCREMENT_COUNTER,
    step
})

export const DECREMENT_COUNTER = 'DECREMENT_COUNTER'
export const decrementCounter = (step) => ({
    type: DECREMENT_COUNTER,
    step
})
