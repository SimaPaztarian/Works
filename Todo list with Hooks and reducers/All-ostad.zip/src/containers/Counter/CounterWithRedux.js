import React, { Component } from 'react'
import { connect } from 'react-redux'
import { decrementCounter, incrementCounter, setCounter } from './CounterAction'

// ------------------------------------ Component ------------------------------------
class CounterWithRedux extends Component {
    render() {
        const {setCounter, decrementCounter, incrementCounter} = this.props
        const {counter} = this.props.CounterReducer

        return (
            <div>
                <h1>Counter with redux</h1>

                <button onClick={() => decrementCounter(10)}>-10</button>
                <button onClick={() => decrementCounter(5)}>-5</button>
                <button onClick={() => decrementCounter()}>-1</button>

                <input value={counter} onChange={setCounter}/>

                <button onClick={() => incrementCounter()}>+1</button>
                <button onClick={() => incrementCounter(5)}>+5</button>
                <button onClick={() => incrementCounter(10)}>+10</button>

            </div>
        )
    }

    // ------------------------------------ Methods ------------------------------------
}

// ------------------------------------ Redux ------------------------------------
const mapStateToProps = store => ({
    CounterReducer: store.CounterReducer
})

const mapDispatchToProps = dispatch => ({
    setCounter: (event) => dispatch(setCounter(event.target.value)),
    incrementCounter: (step = 1) => dispatch(incrementCounter(step)),
    decrementCounter: (step = 1) => dispatch(decrementCounter(step)),
})

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(CounterWithRedux)
