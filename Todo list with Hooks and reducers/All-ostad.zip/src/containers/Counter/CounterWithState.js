import React, { Component } from 'react'

class CounterWithState extends Component {
    state = {
        counter: 0
    }

    decrement = (step = 1) => {
        this.setState(state => ({
            counter: state.counter - step
        }))
    }

    increment = (step = 1) => {
        this.setState(state => ({
            counter: state.counter + step
        }))
    }

    handleChange = (event) => {
        const { name, value } = event.target

        this.setState({
            [name]: parseInt(value)
        })
    }

    render() {
        return (
            <div>
                <h1>Counter with state</h1>

                <button onClick={() => this.decrement(10)}>-10</button>
                <button onClick={() => this.decrement(5)}>-5</button>
                <button onClick={() => this.decrement()}>-1</button>

                <input name={'counter'} value={this.state.counter} onChange={this.handleChange}/>

                <button onClick={() => this.increment()}>+1</button>
                <button onClick={() => this.increment(5)}>+5</button>
                <button onClick={() => this.increment(10)}>+10</button>

            </div>
        )
    }
}

export default CounterWithState
