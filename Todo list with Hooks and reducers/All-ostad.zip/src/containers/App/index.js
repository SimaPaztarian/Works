import React, { Component } from 'react'
import { Provider } from 'react-redux'

import { store } from '../../boot/redux'
import CounterWithState from '../Counter/CounterWithState'
import CounterWithHook from '../Counter/CounterWithHook'
import CounterWithRedux from '../Counter/CounterWithRedux'
import CounterWithHookReducer from '../Counter/CounterWithHookReducer'

class App extends Component {
    render() {
        return (
            <Provider store={store}>
                {/*<CounterWithState/>*/}
                {/*<CounterWithHook/>*/}
                {/*<CounterWithRedux/>*/}
                <CounterWithHookReducer/>
            </Provider>
        )
    }
}

export default App
