import { combineReducers } from "redux";

import TodoReducer from "../containers/TodoApp/TodoReducer";

export default combineReducers({ TodoReducer });
