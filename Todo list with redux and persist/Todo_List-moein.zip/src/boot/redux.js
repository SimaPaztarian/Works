import thunk from "redux-thunk";
import { createLogger } from "redux-logger";
import { createStore, applyMiddleware, compose } from "redux";

import reducer from "./reducers";

const middleware = [thunk];

// middleware.push(createLogger());

export const store = createStore(
     reducer,
     undefined,
     compose(applyMiddleware(...middleware))
);
