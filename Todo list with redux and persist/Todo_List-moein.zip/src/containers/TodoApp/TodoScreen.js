import React, { Component } from "react";
import { connect } from "react-redux";
import "./style.css";

import {
     addTodo,
     changeInput,
     removeTodo,
     toggleEdit,
     swap,
     submitEdit,
     toggleDone,
     restore,
     editChange,
     cancelEdit,
     getLocal,
     shiftDel,
     deleteCompleted,
     undoCompleted,
     moveToggle
} from "./TodoAction";
import { initialState } from "./TodoReducer";

class TodoScreen extends Component {
     componentDidMount() {
          const local =
               JSON.parse(localStorage.getItem("local")) || initialState;

          this.props.getLocal(local);
     }

     componentDidUpdate() {
          const local = this.props.TodoReducer;

          localStorage.setItem("local", JSON.stringify(local));
     }

     handleChange = e => {
          const { value, name } = e.target;

          this.props.changeInput(value, name);
     };
     handleEditChange = (e, todo) => {
          const { value } = e.target;

          this.props.editChange(value, todo);
     };
     handleSubmit = e => {
          e.preventDefault();
          this.props.addTodo();
     };
     render() {

          return (
               <div>
                    <form onSubmit={this.handleSubmit}>
                         <label>
                              Search
                              <input
                                   name="search"
                                   value={this.props.TodoReducer.search}
                                   onChange={this.handleChange}
                              />

                         </label>
                    </form>
                    <form onSubmit={this.handleSubmit}>
                         <label>
                              New Task
                              <input
                                   name="new"
                                   value={this.props.TodoReducer.new}
                                   onChange={this.handleChange}
                              />
                         </label>
                    </form>
                    <h1>TODO LIST</h1>
                    {this.props.TodoReducer.todos.filter((t) => 
                         t.task.includes(this.props.TodoReducer.search)
                    ).map(todo =>
                         !todo.edit ? (
                              <div key={todo.id}>
                                   <label>
                                        <input
                                             type="checkbox"
                                             checked={todo.completed}
                                             onChange={() =>
                                                  this.props.toggleDone(todo)
                                             }
                                        />
                                        <li
                                             style={{
                                                  textDecoration: todo.completed
                                                       ? "line-through"
                                                       : "none",
                                                  color: todo.completed
                                                       ? "green"
                                                       : "black"
                                             }}
                                        >
                                             {todo.task}
                                        </li>
                                   </label>
                                   <button
                                        onClick={() => {
                                             this.props.removeTodo(todo);
                                        }}
                                   >
                                        Remove
                                   </button>
                                   <button
                                        onClick={() => {
                                             this.props.toggleEdit(todo.id);
                                             this.props.swap(todo.task);
                                        }}
                                   >
                                        Edit
                                   </button>
                                   <button onClick={() => {
                                             this.props.moveToggle(todo, +1);
                                        }}>up</button>
                                   <button onClick={() => {
                                             this.props.moveToggle(todo, -1);
                                        }}>down</button>
                              </div>
                         ) : (
                              <form
                                   key={todo.id}
                                   onSubmit={() =>
                                        this.props.submitEdit(todo.id)
                                   }
                              >
                                   <input
                                        autoFocus
                                        name="edit"
                                        value={todo.editValue}
                                        onChange={e =>
                                             this.handleEditChange(e, todo)
                                        }
                                   />
                                   <button>Save</button>
                                   <button
                                        type="button"
                                        onClick={() =>
                                             this.props.cancelEdit(todo)
                                        }
                                   >
                                        Cancel
                                   </button>
                              </form>
                         )
                    )}

                    <div className="">
                         <h1>COMPLETED TASKS</h1>
                         {this.props.TodoReducer.completed.filter((todo) => 
                         todo.task.includes(this.props.TodoReducer.search)
                    ).map(t => (
                              <>
                                   <li key={t.id}>{t.task}</li>
                                   <button
                                        onClick={() => {
                                             this.props.deleteCompleted(t);
                                        }}
                                   >
                                        delete
                                   </button>
                                   <button
                                        onClick={() => {
                                             this.props.undoCompleted(t);
                                        }}
                                   >
                                        undone
                                   </button>
                              </>
                         ))}
                    </div>

                    <div className="deletedTodos">
                         <h1>TRASH Todos</h1>
                         {this.props.TodoReducer.deleted.filter((t) => 
                         t.task.includes(this.props.TodoReducer.search)
                    ).map(todo => (
                              <div key={todo.id}>
                                   <li className="deletedList">{todo.task}</li>
                                   <button
                                        onClick={() => {
                                             this.props.shiftDel(todo);
                                        }}
                                   >
                                        Shift + Del
                                   </button>
                                   <button
                                        onClick={() => {
                                             this.props.restore(todo);
                                        }}
                                   >
                                        Restore
                                   </button>
                              </div>
                         ))}
                    </div>
               </div>
          );
     }
}
const mapStateToProp = store => ({
     TodoReducer: store.TodoReducer
});

const mapDispatch = dispatch => ({
     addTodo: () => dispatch(addTodo()),
     changeInput: (value, name) => dispatch(changeInput(value, name)),
     removeTodo: todo => dispatch(removeTodo(todo)),
     toggleEdit: id => dispatch(toggleEdit(id)),
     swap: value => dispatch(swap(value)),
     submitEdit: id => dispatch(submitEdit(id)),
     toggleDone: todo => dispatch(toggleDone(todo)),
     restore: todo => dispatch(restore(todo)),
     editChange: (value, todo) => dispatch(editChange(value, todo)),
     cancelEdit: todo => dispatch(cancelEdit(todo)),
     getLocal: local => dispatch(getLocal(local)),
     shiftDel: todo => dispatch(shiftDel(todo)),
     deleteCompleted: todo => dispatch(deleteCompleted(todo)),
     undoCompleted: todo => dispatch(undoCompleted(todo)),
     moveToggle: (todo, dir) => dispatch(moveToggle(todo, dir)),

});
export default connect(
     mapStateToProp,
     mapDispatch
)(TodoScreen);
