export const ADD_TODO = "ADD_TODO";
export const addTodo = () => {
     return {
          type: ADD_TODO
     };
};

export const CHANGE_INPUT='CHANGE_INPUT'
export const changeInput= (value , name) => {
     
     return{
          type:CHANGE_INPUT,
          value,
          name
     }
}
export const REMOVE_TODO='REMOVE_TODO'
export const removeTodo= todo => {
     return{
          type:REMOVE_TODO,
          todo
     }
}

export const TOGGLE_EDIT='TOGGLE_EDIT'
export const toggleEdit = id=> {
     return{
          type:TOGGLE_EDIT,
          id
     }
}

export const TOGGLE_DONE='TOGGLE_DONE'
export const toggleDone = todo => {
     return{
          type:TOGGLE_DONE,
          todo
     }
}

export const SWAP='SWAP'
export const swap = value => {
     return{
          type:SWAP,
          value
     }
}

export const SUBMIT_EDIT='SUBMIT_EDIT'
export const submitEdit= id=> {
     return{
          type:SUBMIT_EDIT,
          id
     }
}

export const RESTORE='RESTORE'
export const restore= todo => {
     return{
          type:RESTORE,
          todo
     }
}

export const EDIT_CHANGE='EDIT_CHANGE'
export const editChange= (value , todo) => {
     return{
          type:EDIT_CHANGE,
          value,
          todo
     }
}

export const CANCEL_EDIT='CANCEL_EDIT'
export const cancelEdit= (todo) => {
     return{
          type:CANCEL_EDIT,
          todo
     }
}

export const GET_LOCAL = 'GET_LOCAL';
export const getLocal = (local) => {
     return {
          type: GET_LOCAL,
          local
     }
}
export const SHIFT_DEL='SHIFT_DEL'
export const shiftDel= (todo) => {
     return{
          type:SHIFT_DEL,
          todo
     }
}
export const DEL_COMPLETED='DEL_COMPLETED'
export const deleteCompleted= (todo) => {
     return{
          type:DEL_COMPLETED,
          todo
     }
}
export const UNDO_COMPLETED='UNDO_COMPLETED'
export const undoCompleted= (todo) => {
     return{
          type:UNDO_COMPLETED,
          todo
     }
}
export const MOVE_TOGGLE='MOVE_TOGGLE'
export const moveToggle= (todo, dir) => {
     return{
          type:MOVE_TOGGLE,
          todo,
          dir
     }
}