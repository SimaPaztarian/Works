import uuid from "uuid/v4";

import {
     ADD_TODO,
     CHANGE_INPUT,
     REMOVE_TODO,
     TOGGLE_EDIT,
     SWAP,
     SUBMIT_EDIT,
     TOGGLE_DONE,
     RESTORE,
     EDIT_CHANGE,
     CANCEL_EDIT,
     GET_LOCAL,
     SHIFT_DEL,
     DEL_COMPLETED,
     UNDO_COMPLETED,
     MOVE_TOGGLE
} from "./TodoAction";

export const initialState = {
     todos: [],
     new: "",
     search: "",
     deleted: [],
     completed: []
};

const TodoReducer = (state = initialState, action = {}) => {
     const { type, value, id, todo, local, name, dir } = action;
     switch (type) {
          case ADD_TODO:
               if (!state.new) {
                    return {
                         ...state
                    };
               }
               return {
                    ...state,
                    todos: [
                         {
                              task: state.new,
                              id: uuid(),
                              completed: false,
                              trash: false,
                              edit: false,
                              editValue: state.new
                         },
                         ...state.todos
                    ],
                    new: ""
               };
          case CHANGE_INPUT:
               return {
                    ...state,
                    [name]: value
               };
          case REMOVE_TODO:
               return {
                    ...state,
                    todos: state.todos.filter(t => t.id !== todo.id),
                    deleted: [
                         ...state.deleted,
                         {
                              ...todo
                         }
                    ]
               };
          case TOGGLE_EDIT:
               return {
                    ...state,
                    todos: state.todos.map(todo => {
                         if (todo.id === id) {
                              return {
                                   ...todo,
                                   edit: !todo.edit
                              };
                         }
                         return todo;
                    })
               };

          case TOGGLE_DONE:
               return {
                    ...state,
                    todos: state.todos.filter(t => t.id !== todo.id),
                    completed: [...state.completed, todo]
               };

          case SWAP:
               return {
                    ...state,
                    edit: value
               };

          case SUBMIT_EDIT:
               return {
                    ...state,
                    todos: state.todos.map(todo => {
                         if (todo.id === id) {
                              return {
                                   ...todo,
                                   edit: false,
                                   task: todo.editValue
                              };
                         }
                         return todo;
                    })
               };

          case RESTORE:
               return {
                    ...state,
                    deleted: state.deleted.filter(t => t.id !== todo.id),
                    todos: [
                         ...state.todos,
                         {
                              ...todo,
                              completed: false
                         }
                    ]
               };

          case EDIT_CHANGE:
               return {
                    ...state,
                    todos: state.todos.map(t => {
                         if (t.id === todo.id) {
                              return {
                                   ...todo,
                                   editValue: value
                              };
                         }
                         return t;
                    })
               };

          case CANCEL_EDIT:
               return {
                    ...state,
                    todos: state.todos.map(t => {
                         if (t.id === todo.id) {
                              return {
                                   ...todo,
                                   edit: false,
                                   editValue: todo.task
                              };
                         }
                         return t;
                    })
               };

          case GET_LOCAL:
               return local;
          case SHIFT_DEL:
               return {
                    ...state,
                    deleted: state.deleted.filter(t => t.id !== todo.id)
               };
          case DEL_COMPLETED:
               return {
                    ...state,
                    completed: state.completed.filter(t => t.id !== todo.id),
                    deleted: [
                         ...state.deleted,
                         {
                              ...todo
                         }
                    ]
               };
          case UNDO_COMPLETED:
               return {
                    ...state,
                    completed: state.completed.filter(t => t.id !== todo.id),
                    todos: [
                         ...state.todos,
                         {
                              ...todo
                         }
                    ]
               };
          case MOVE_TOGGLE:
               let target_index;
               const newTodos = state.todos.filter((t, index) => {
                    if (t.id === todo.id) {
                         target_index = index;
                         return false;
                    }
                    return true;
               });
               if (!target_index && dir === 1) return state;
               newTodos.splice(target_index - dir, 0, todo);
               return {
                    ...state,
                    todos: [...newTodos]
               };
          // state.todos.forEach((t, i) => {
          //      if (t.id === todo.id) {
          //           target_index = i;
          //      }
          // });

          // if (!target_index) return { ...state };
          // const check_dir = dir === 1 ? target_index - 1: target_index + 1;
          // const other_todo = state.todos[check_dir];
          // const new_todos = state.todos.map((t, ind) => {
          //      if (ind === check_dir) {
          //           return todo;
          //      }
          //      if (ind === target_index) {
          //           return other_todo;
          //      }
          //      return t;
          // });
          // // const new_state = {...state, state.todos}
          // return {
          //      ...state,
          //      todos: new_todos
          // };

          default:
               return state;
     }
};
export default TodoReducer;
