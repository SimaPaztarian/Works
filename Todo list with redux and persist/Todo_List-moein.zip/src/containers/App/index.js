import React, { Component } from "react";
import { Provider } from "react-redux";

import { store } from "../../boot/redux";
import TodoScreen from "../TodoApp/TodoScreen";

class index extends Component {
     render() {
          return (
               <Provider store={store}>
                    <TodoScreen />
               </Provider>
          );
     }
}

export default index;
